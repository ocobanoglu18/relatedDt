﻿using System;
using System.Collections.Generic;
using LumenWorks.Framework.IO.Csv;

namespace userEmailDomainInfo
{
	public static class Helper

	{
		

		public static List<string> Emails = new List<string>()
		{
			//"deniz.kocabas@euromsg.com",
			//"adnancobanoglu@hotmail.com",
			//"deniz.kocaboga@gmail.com",
			//"deniz.kocaboga@gmail.com.tr",
			//"deniz.kocaboga@hede.hodo.com",
			//"deniz.kocaboga@hede",
			//"deniz.kocaboga_hede",
	
		};

	}
}

